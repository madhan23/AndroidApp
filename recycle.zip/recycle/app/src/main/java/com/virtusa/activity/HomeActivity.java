package com.virtusa.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.virtusa.Config;
import com.virtusa.Connection;
import com.virtusa.models.ShopDetailList;
import com.virtusa.recycle.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    List<String> druglist=new ArrayList<String>();
   List<ShopDetailList> shopdetailslist=new ArrayList<ShopDetailList>();
    RequestQueue requestQueue1;
    ProgressDialog pd;
    String[] singleInputs=null;
    private MultiAutoCompleteTextView editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        if(Connection.isConnected(HomeActivity.this)) {
            pd = new ProgressDialog(HomeActivity.this);
            pd.setMessage("Loading DrugList...");
            pd.show();
            dataload();
            editText = findViewById(R.id.drug_list);
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1, druglist);
            editText.setAdapter(adapter);
            editText.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        }else
            errorMessage();
    }

    public void showTable(View v) {
        // System.out.print("**********************************"+getIntent().getStringExtra("place"));
        String input = editText.getText().toString();

        if (input.length() <= 0) {

            Toast.makeText(this, "DrugField cannot be empty..", Toast.LENGTH_SHORT).show();
            editText.setError("DrugField cannot be empty");

        } else {
            if (input.indexOf(",") == -1)
                Toast.makeText(this, "Type valid Drug Name", Toast.LENGTH_SHORT).show();
            else {
                editText.setError(null);
                boolean check=true;
                input=input.trim();
                singleInputs = input.split(",");
                if (singleInputs.length <= 0){
                    check = false;
                }else {
                    for (int i = 0; i < singleInputs.length; i++) {
                        singleInputs[i] = singleInputs[i].toString();
                        System.out.println("hhh" + singleInputs[i].toString() + "   " + druglist.contains(singleInputs[i].toString()) + "len" + singleInputs[i].toString().length());
                        if (singleInputs[i].toString().trim().length() == 0 || druglist.contains(singleInputs[i].toString()) == false)
                            check = false;


                    }
                }
                if(check==true)
                dopost();
                else
                    Toast.makeText(this, "Type valid Drug Name", Toast.LENGTH_SHORT).show();
            }


        }
    }



    private  void dataload() {

        requestQueue1 = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET,Config.DrugListUrl, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                pd.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonarray=jsonObject.getJSONArray("druglist");
                  if(jsonarray!=null) {
                   for(int i=0;i<jsonarray.length();druglist.add(jsonarray.get(i++).toString()));
                  }
                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Server Error", Toast.LENGTH_LONG).show();
                }
                //Log.i("VOLLEY", response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
        requestQueue1.add(stringRequest);
    }
    public  void dopost(){
        pd.setMessage("Loading...");
        pd.show();
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            List<String> dList = Arrays.asList(singleInputs);
            JSONObject jsonBody = new JSONObject();
            JSONArray list = new JSONArray( dList);
            String area=getIntent().getStringExtra("place");
            area=area.trim();
           jsonBody.put("area",area);
            jsonBody.put("drugName",list);
            System.out.println("********************************************8JSON"+jsonBody);
            final String mRequestBody = jsonBody.toString();
            System.out.println("********************************************8JSON"+mRequestBody);
            StringRequest stringRequest = new StringRequest(Request.Method.POST,Config.pharamacyUrl , new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    ArrayList<ShopDetailList> shoplist;
                    pd.dismiss();
                    try {
                        JSONArray jsonarray = new JSONArray(response);
                        Gson gson = new Gson();
                        if(jsonarray!=null)

                        {   TypeToken<List<ShopDetailList>> token = new TypeToken<List<ShopDetailList>>(){};
                             shoplist = gson.fromJson(response, token.getType());
                            if(Connection.isConnected(HomeActivity.this)){
                                Intent i=new Intent(HomeActivity.this,RecycleViewLayout.class);
                                Bundle bundle = new Bundle();
                                bundle.putSerializable("shopdetails", shoplist);
                                i.putExtras(bundle);
                                startActivity(i);
                            }else
                                errorMessage();

                        }



                    } catch (JSONException e) {
                        Toast.makeText(HomeActivity.this, "Invalid DrugList", Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    pd.dismiss();
                    Log.e("LOG_VOLLEY", error.toString());
                    Toast.makeText(HomeActivity.this, "Enter a valid drugs..", Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return mRequestBody == null ? null : mRequestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", mRequestBody, "utf-8");
                        return null;
                    }
                }
            };

            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    void errorMessage(){
        Toast.makeText(this,"No  Internet Connection", Toast.LENGTH_SHORT).show();

    }

}
