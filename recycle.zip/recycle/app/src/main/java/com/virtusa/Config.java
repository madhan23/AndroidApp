package com.virtusa;

public class Config {
    public static final String loginUrl="https://drugwebdemo.herokuapp.com/login/";
    public static final String DrugListUrl="https://drugwebdemo.herokuapp.com/drug";
    public static final String pharamacyUrl="https://drugwebdemo.herokuapp.com/drug/details";
    public static final String areaListUrl="https://drugwebdemo.herokuapp.com/pharmacy/area";
}
