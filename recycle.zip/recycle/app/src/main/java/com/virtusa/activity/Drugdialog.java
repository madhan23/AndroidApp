package com.virtusa.activity;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.virtusa.Connection;
import com.virtusa.models.DrugList;
import com.virtusa.models.ShopDetailList;
import com.virtusa.recycle.R;

import java.util.ArrayList;
import java.util.List;

public class Drugdialog extends AppCompatActivity {
 Button backbtn;
 TextView pills,pills_price,totalAmt,pills_notAvail,drugcontentHeader;
    List<DrugList> druglist=null;
    double price=0;
    boolean drug_avail=true;
    String avail_Drugs="",notAvail_Drugs="",price_Info="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drugdialog);
        if(Connection.isConnected(Drugdialog.this)){
            backbtn=findViewById(R.id.back);
            pills=findViewById(R.id.drugs);
            pills_price=findViewById(R.id.price);
            totalAmt=findViewById(R.id.total);
            drugcontentHeader=findViewById(R.id.notavailabledrugslist);
            pills_notAvail=findViewById(R.id.not_availdrugs);
            pills_notAvail.setTextColor(Color.RED);
            Bundle bundle = this.getIntent().getExtras();
            if (bundle != null) {
                druglist = (List<DrugList>) bundle.getSerializable("PillsInformation");
                System.out.println(druglist.size());
            }

            for(DrugList drug:druglist){
                System.out.println(drug.getIsAvailable());
                if(drug.getIsAvailable().equals("Y")) {
                    avail_Drugs += drug.getDrugName() + "\n";
                    price_Info+=drug.getDrugPriceEach()+"\n";
                    price+=drug.getDrugPriceEach();
                }
                else{
                    drug_avail=false;
                    notAvail_Drugs+=drug.getDrugName()+"\n";
                }



            }

            pills.setText(avail_Drugs);
            pills_price.setText(price_Info);
            totalAmt.setText(String.valueOf(Math.ceil(price))+" Rs");

            if(drug_avail==false)
            {   pills_notAvail.setVisibility(View.VISIBLE);
                drugcontentHeader.setVisibility(View.VISIBLE);
                pills_notAvail.setText(notAvail_Drugs);

            }
        }else
            Toast.makeText(this,"No  Internet Connection", Toast.LENGTH_SHORT).show();

        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}
