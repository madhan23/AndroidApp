package com.virtusa.models;

public class DrugInformation {

}
