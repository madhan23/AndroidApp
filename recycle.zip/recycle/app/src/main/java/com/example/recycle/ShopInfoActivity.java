package com.example.recycle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class ShopInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_info);
        TextView textview =findViewById(R.id.drugname);
         ArrayList<String> drugNames=getIntent().getStringArrayListExtra("d");
         String result="";
   for(String drugName: drugNames){
       result+=drugName+"\n";
   }

        textview.setText(result);
    }
}
