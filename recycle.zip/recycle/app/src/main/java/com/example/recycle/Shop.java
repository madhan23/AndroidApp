package com.example.recycle;


public class Shop {
private int shop_id;
private String shopName;
private double distance;
private double price; 
private String opentime;
private String closetime;
private Medicine medicines;

public void setShop_id(int shop_id) {
	this.shop_id = shop_id;
}
public void setShopName(String shopName) {
	this.shopName = shopName;
}
public void setDistance(double distance) {
	this.distance = distance;
}
public void setPrice(double price) {
	this.price = price;
}
public void setOpentime(String opentime) {
	this.opentime = opentime;
}
public void setClosetime(String closetime) {
	this.closetime = closetime;
}
public void setMedicines(Medicine medicines) {
	this.medicines = medicines;
}

public int getShop_id() {
	return shop_id;
}
public String getShopName() {
	return shopName;
}
public double getDistance() {
	return distance;
}
public double getPrice() {
	return price;
}
public String getOpentime() {
	return opentime;
}
public String getClosetime() {
	return closetime;
}
public Medicine getMedicines() {
	return medicines;
}

public Shop() {
	super();
}
	
}
