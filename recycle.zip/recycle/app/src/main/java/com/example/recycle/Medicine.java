package com.example.recycle;

import java.util.ArrayList;
import java.util.HashMap;

public class Medicine {
private int mid;
private HashMap <String,Double>druglist;

public Medicine() {
	super();
}

public int getMid() {
	return mid;
}

public void setMid(int mid) {
	this.mid = mid;
}



	public ArrayList<String> Druglist() {

        ArrayList<String> drugNames = new ArrayList<String>(this.druglist.keySet());

    return drugNames;
}

public void setDruglist(HashMap<String, Double> druglist) {
	this.druglist = druglist;
}




}
