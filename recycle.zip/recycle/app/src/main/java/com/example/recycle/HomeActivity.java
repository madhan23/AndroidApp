package com.example.recycle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    private static final String[] drugList = new String[]{
            "Aspirin 2mg", "Aspirin 5mg","benzol 100mg","paracetamol 100 mg","paracetamol 500 mg","Dolox 100 mg","Dolox 600 mg"
    };
    private MultiAutoCompleteTextView editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        editText = findViewById(R.id.mactv);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,drugList);
        editText.setAdapter(adapter);
        editText.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
    }
    public void showInput(View v) {
        String input = editText.getText().toString().trim();
        String[] singleInputs = input.split("\\s*,\\s*");


        String toastText = "";

        for (int i = 0; i < singleInputs.length; i++) {

            toastText += "Item " + i + ": " + singleInputs[i] + "\n";
        }

        Toast.makeText(this, toastText, Toast.LENGTH_SHORT).show();
    }
    public void showTable(View v){
        Intent i=new Intent(HomeActivity.this,RecycleViewLayout.class);
        startActivity(i);
    }
}
