package com.example.recycle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RecycleViewLayout extends AppCompatActivity implements MyRecyclerViewAdapter.ItemClickListener {

    MyRecyclerViewAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_view_layout);
        // data to populate the RecyclerView with
        Medicine med1,med2,med3,med4,med5;
        Shop s1,s2,s3,s4,s5;
        HashMap<String,Double> medinfo,medinfo2,medinfo3,medinfo4,medinfo5;
        medinfo=new HashMap();
        s1=new Shop();
        s1.setShop_id(101);
        s1.setShopName("apollo");
        s1.setDistance(100);
        s1.setPrice(20);
        s1.setOpentime("8:10");
        s1.setClosetime("10:00");
        med1=new Medicine();
        med1.setMid(1);
        medinfo=new HashMap();

        medinfo.put("Aspirin 2mg",new Double(5));
        medinfo.put("Aspirin 5mg",new Double(10));
        medinfo.put("benzol 100mg",new Double(20));
        medinfo.put("paracetamol 100 mg",new Double(12));
        medinfo.put("Dolox 100 mg",new Double(14));
        medinfo.put("Dolox 600 mg",new Double(18));
        med1.setDruglist(medinfo);
        s1.setMedicines(med1);

        s2=new Shop();
        med2=new Medicine();
        medinfo2=new HashMap();
        s2.setShop_id(102);
        s2.setShopName("NK");
        s2.setDistance(150);
        s2.setPrice(30);
        s2.setOpentime("9:10");
        s2.setClosetime("8:00");
        med2=new Medicine();
        med2.setMid(2);

        medinfo2.put("Aspirin 2mg",new Double(1));
        medinfo2.put("Aspirin 5mg",new Double(10));
        medinfo2.put("benzol 100mg",new Double(20));
        medinfo2.put("paracetamol 100 mg",new Double(12));
        medinfo2.put("Dolox 100 mg",new Double(14));
        medinfo2.put("Dolox 600 mg",new Double(18));
        med2.setDruglist(medinfo2);
        s2.setMedicines(med2);

        s3=new Shop();
        med3=new Medicine();
        medinfo3=new HashMap();
        s3.setShop_id(103);
        s3.setShopName("mediplus");
        s3.setMedicines(med2);
        s3.setDistance(250);
        s3.setPrice(33);
        s3.setOpentime("10:10");
        s3.setClosetime("8:00");
        med3.setMid(3);

        medinfo3.put("Aspirin 2mg",new Double(2));
        medinfo3.put("Aspirin 5mg",new Double(13));
        medinfo3.put("benzol 100mg",new Double(21));
        medinfo3.put("paracetamol 100 mg",new Double(11));
        medinfo3.put("Dolox 100 mg",new Double(12));
        medinfo3.put("Dolox 600 mg",new Double(13));
        med3.setDruglist(medinfo3);
        s3.setMedicines(med3);

        s4=new Shop();
        med4=new Medicine();
        medinfo4=new HashMap();
        s4.setShop_id(103);
        s4.setShopName("mediplus");
        s4.setMedicines(med2);
        s4.setDistance(250);
        s4.setPrice(33);
        s4.setOpentime("10:10");
        s4.setClosetime("8:00");
        med4.setMid(4);

        medinfo4.put("Aspirin 2mg",new Double(2));
        medinfo4.put("Aspirin 5mg",new Double(13));
        medinfo4.put("benzol 100mg",new Double(21));
        medinfo4.put("paracetamol 100 mg",new Double(11));
        medinfo4.put("Dolox 100 mg",new Double(12));
        medinfo4.put("Dolox 600 mg",new Double(13));
        med4.setDruglist(medinfo4);
        s4.setMedicines(med4);

        s5=new Shop();
        med5=new Medicine();
        medinfo5=new HashMap();
        s5.setShop_id(103);
        s5.setShopName("mediplus");
        s5.setMedicines(med2);
        s5.setDistance(250);
        s5.setPrice(33);
        s5.setOpentime("10:10");
        s5.setClosetime("8:00");
        med5.setMid(5);

        medinfo5.put("Aspirin 2mg",new Double(2));
        medinfo5.put("Aspirin 5mg",new Double(13));
        medinfo5.put("benzol 100mg",new Double(21));
        medinfo5.put("paracetamol 100 mg",new Double(11));
        medinfo5.put("Dolox 100 mg",new Double(12));
        medinfo5.put("Dolox 600 mg",new Double(13));
        med5.setDruglist(medinfo5);
        s5.setMedicines(med5);


        ArrayList<Shop> animalNames = new ArrayList<>();
        animalNames.add(s1);
        animalNames.add(s2);
        animalNames.add(s3);
        animalNames.add(s4);
        animalNames.add(s5);



        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.rvAnimals);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MyRecyclerViewAdapter(this, animalNames);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);


    }

    @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(this, "You clicked " + adapter.getItem(position).getShopName(), Toast.LENGTH_SHORT).show();
        Intent i=new Intent(this,ShopInfoActivity.class);
        ArrayList<String> druglist= new ArrayList<String>(adapter.getItem(position).getMedicines().Druglist());
        i.putStringArrayListExtra("d",druglist);
    startActivity(i);
    }
}