package com.example.recycle;

public class MyListData {
    public MyListData(String description, int imgId, String fname, String lname) {
        this.description = description;
        this.imgId = imgId;
        this.fname = fname;
        this.lname = lname;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getImgId() {
        return imgId;
    }

    public void setImgId(int imgId) {
        this.imgId = imgId;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    private String description;
    private int imgId;
    private String fname;
    private String lname;

}





