package com.virtusa.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnSuccessListener;
import com.virtusa.Config;
import com.virtusa.Connection;
import com.virtusa.recycle.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LocationActivity extends AppCompatActivity {

private Geocoder geocoder;
private FusedLocationProviderClient client;
private List<Address> addressList;
RequestQueue requestQueue;
ProgressDialog pd;
private List<String> arealist;
private TextView currentlocation;
String place="";
Button submit;
AutoCompleteTextView editText;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        // checking internet connection......
        if(Connection.isConnected(LocationActivity.this))  {
            getAreaList();
            pd= new ProgressDialog(LocationActivity.this);
            pd.setMessage("Loading AreaList...");
            pd.show();
            submit=findViewById(R.id.currentloc_btn);
            currentlocation=findViewById(R.id.loc_area);
            // sharing content one activity any other activity
            sharedpreferences = getApplicationContext().getSharedPreferences("LocationInformations", Context.MODE_PRIVATE);
            editor = sharedpreferences.edit();
            arealist=new ArrayList<>();
            editText = findViewById(R.id.area_list);

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arealist);
            editText.setAdapter(adapter);
            editText.addTextChangedListener(new TextWatcher() {

                public void afterTextChanged(Editable s) {
                    System.out.println("afterTextChanged");

                    String areaName=editText.getText().toString();
                    if(areaName.length()==0)
                        submit.setEnabled(true);
                }

                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    System.out.println("beforeTextChanged...............");

                }

                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    System.out.println("onTextChanged...............");
                    currentlocation.setText("");
                    submit.setEnabled(false);

                }
            });
            // while page loads itself get location permisssion......
            requestPermission();
            client = LocationServices.getFusedLocationProviderClient(this);


        }else{
            Toast.makeText(this,"No  Internet Connection", Toast.LENGTH_SHORT).show();

        }



    }

public void locationDirection( String area)
{
        try {
            Geocoder gc = new Geocoder(this);
            List<Address> addrs=gc.getFromLocationName(area, 1); // get the found Address Objects
        Address address=addrs.get(0);
            LatLng latlng=new LatLng(address.getLatitude(),address.getLongitude());

            System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"+latlng.latitude+"m"+latlng.longitude);
            editor.putString("Latitude",String.valueOf(latlng.latitude));
            editor.putString("Longitude",String.valueOf(latlng.longitude));
            editor.apply();
        } catch (IOException e) {
            System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        }

}
    public void currentLocationTracker(View v) {



        geocoder=new Geocoder(this, Locale.getDefault());

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Allow Location Permission to access", Toast.LENGTH_SHORT).show();
            return;
        }
        client.getLastLocation().addOnSuccessListener(LocationActivity.this, new OnSuccessListener<Location>() {
            double longitude = 0, latitude = 0;

            @Override
            public void onSuccess(Location location) {

                if (location != null) {
                    longitude = location.getLongitude();
                    latitude = location.getLatitude();
                    try{
                        addressList=geocoder.getFromLocation(latitude,longitude,1);
                        String fullAddressDetails=addressList.get(0).getAddressLine(0);

                        String address[]=fullAddressDetails.split(",");
                        //textview.setText(address[address.length-4]);
                        //Toast.makeText(HomeActivity.this, "Your City id:"+address[address.length-4], Toast.LENGTH_SHORT).show();
                        place=address[address.length-4];
                        currentlocation.setText(fullAddressDetails);
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                    //
                    // 5Toast.makeText(LocationActivity.this, location.getLongitude()+" "+location.getLatitude(), Toast.LENGTH_SHORT).show();


                    editor.putString("Latitude",String.valueOf(latitude));
                    editor.putString("Longitude",String.valueOf(longitude));

                    editor.apply();
//                    Intent intent=new Intent(HomeActivity.this,HomeActivity.class);
//                    startActivity(intent);
                }

                Log.d("Latitude", longitude + "@@@@@@" + latitude);


            }

        });

    }

    private void requestPermission(){
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
    }


public void onSubmit(View v) {
// checking internet connection......
    if(Connection.isConnected(LocationActivity.this)) {
        if (TextUtils.isEmpty(currentlocation.getText().toString()) && TextUtils.isEmpty(editText.getText().toString()))
            Toast.makeText(this, "Please choose your current Location..", Toast.LENGTH_SHORT).show();
        else {
            if (editText.getText().toString().length() != 0) {
                locationDirection(editText.getText().toString());
                place = editText.getText().toString();

            }

            Intent i = new Intent(this, HomeActivity.class);
            i.putExtra("place", place);
            startActivity(i);
        }

    }else{
            Toast.makeText(this, "No  Internet Connection", Toast.LENGTH_SHORT).show();
    }
}



    private void getAreaList() {
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Config.areaListUrl, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                pd.dismiss();
                try {
                    JSONObject object=new JSONObject(response);
                    JSONArray jsonarray =object.getJSONArray("area");
           if(jsonarray.length()!=0){
               for(int i=0;i<jsonarray.length();arealist.add(jsonarray.get(i++).toString()));
           }

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Server Error", Toast.LENGTH_LONG).show();
                }
                //Log.i("VOLLEY", response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
        requestQueue.add(stringRequest);
        }

    // making a close app dialog box......
    @Override   // Ctrl + o override method
    public void onBackPressed() {
        // create a Alertdialog box
        AlertDialog.Builder alertdialog = new AlertDialog.Builder(this);
        alertdialog.setTitle("Confirm Exit...!");
        alertdialog.setMessage("Are you sure you want to exit app");
        alertdialog.setCancelable(false);
        alertdialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finishAffinity();

            }
        });
        alertdialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(LocationActivity.this, "You Clicked Cancel Button", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog alert = alertdialog.create();
        alert.show();
    }


}