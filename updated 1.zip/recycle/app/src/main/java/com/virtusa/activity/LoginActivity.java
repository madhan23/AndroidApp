package com.virtusa.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.virtusa.Config;
import com.virtusa.recycle.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class LoginActivity extends AppCompatActivity {
    EditText userName, Password;
    private RequestQueue requestQueue;
    ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //initialize Progress bar to context layout
        pd= new ProgressDialog(LoginActivity.this);
        if (!isConnected(LoginActivity.this))
            buildDialog(LoginActivity.this).show();   //  checking Interent Connection...
        else {
            Toast.makeText(LoginActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
            setContentView(R.layout.activity_login);
        }

    }
// making a close app dialog box......
    @Override   // Ctrl + o override method
    public void onBackPressed() {
        // create a Alertdialog box
        AlertDialog.Builder alertdialog = new AlertDialog.Builder(this);
        alertdialog.setTitle("confirm Exit...!");
        alertdialog.setMessage("Are you sure you want to exit app");
        alertdialog.setCancelable(false);
        alertdialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();

            }
        });
        alertdialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(LoginActivity.this, "You Clicked Cancel Button", Toast.LENGTH_SHORT).show();
            }
        });
        AlertDialog alert = alertdialog.create();
        alert.show();
    }


    public boolean isConnected(Context context) {   //  checking a Network connection.........

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netinfo = cm.getActiveNetworkInfo();

        if (netinfo != null && netinfo.isConnectedOrConnecting()) {
            android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

            if ((mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting()))
                return true;
            else return false;
        } else
            return false;
    }


    public AlertDialog.Builder buildDialog(Context c) {    // no internet connection......

        AlertDialog.Builder builder = new AlertDialog.Builder(c);
        builder.setTitle("No Internet Connection");
        builder.setMessage("You need to have Mobile Data or wifi to access this. Press ok to Exit");

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                finish();
            }
        });

        return builder;
    }


    public void login(View v) {
        userName =(EditText)findViewById(R.id.user);
        Password = (EditText)findViewById(R.id.pass);
        pd.setMessage("please wait");
        pd.show();
        String data = "{"+
                "\"userName\"" + ":\"" + userName.getText().toString() + "\","+
                "\"userPassword\"" + ":\"" + Password.getText().toString() + "\""+
                "}";
        System.out.println(data);
        Submit(data);



    }


    private void Submit(String data) {
        final String savedata = data;

     String getUrl= Config.loginUrl;
System.out.println("URL****************"+getUrl);
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.POST,getUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                pd.dismiss();
                userName.setText("");
                Password.setText("");
                try {
                    JSONObject jsonObject = new JSONObject(response);


                        if(jsonObject.getString("message").equals("Login Success")){
                            Intent i=new Intent(LoginActivity.this,HomeActivity.class);
                            startActivity(i);
                        }




                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Invalid Username and password", Toast.LENGTH_LONG).show();
                }
                //Log.i("VOLLEY", response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();

                //Log.v("VOLLEY", error.toString());
            }
        }) {
            @Override
            public String getBodyContentType() {
                return "application/json";
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    return savedata == null ? null : savedata.getBytes("utf-8");
                } catch (UnsupportedEncodingException uee) {
                    //Log.v("Unsupported Encoding while trying to get the bytes", data);
                    return null;
                }
            }

        };
        requestQueue.add(stringRequest);
    }

}
