package com.virtusa.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MedicalShop {

	public static void main(String[] args) {
		Medicine med1,med2,med3;
		Shop s1,s2,s3;
		HashMap<String,Double> medinfo,medinfo2,medinfo3;
		medinfo=new HashMap();
		s1=new Shop();
		s1.setShop_id(101);
		s1.setShopName("apollo");
		s1.setDistance(100);
		s1.setPrice(20);
		s1.setOpentime("8:10");
		s1.setClosetime("10:00");
		med1=new Medicine();
		med1.setMid(1);
		medinfo=new HashMap();
		
		medinfo.put("Aspirin 2mg",new Double(5));
		medinfo.put("Aspirin 5mg",new Double(10));
		medinfo.put("benzol 100mg",new Double(20));
		medinfo.put("paracetamol 100 mg",new Double(12));
		medinfo.put("Dolox 100 mg",new Double(14));
		medinfo.put("Dolox 600 mg",new Double(18));
		med1.setDruglist(medinfo);
		s1.setMedicines(med1);
		
		s2=new Shop();
		med2=new Medicine();
		medinfo2=new HashMap();
		s2.setShop_id(102);
		s2.setShopName("NK");
		s2.setDistance(150);
		s2.setPrice(30);
		s2.setOpentime("9:10");
		s2.setClosetime("8:00");
		med2=new Medicine();
		med2.setMid(2);
		
		medinfo2.put("Aspirin 2mg",new Double(1));
		medinfo2.put("Aspirin 5mg",new Double(10));
		medinfo2.put("benzol 100mg",new Double(20));
		medinfo2.put("paracetamol 100 mg",new Double(12));
		medinfo2.put("Dolox 100 mg",new Double(14));
		medinfo2.put("Dolox 600 mg",new Double(18));
		med2.setDruglist(medinfo2);
		s2.setMedicines(med2);
		
		s3=new Shop();
		med3=new Medicine();
		medinfo3=new HashMap();
		s3.setShop_id(103);
		s3.setShopName("mediplus");
		s3.setMedicines(med2);
		s3.setDistance(250);
		s3.setPrice(33);
		s3.setOpentime("10:10");
		s3.setClosetime("8:00");
		med3.setMid(3);
		
		medinfo3.put("Aspirin 2mg",new Double(2));
		medinfo3.put("Aspirin 5mg",new Double(13));
		medinfo3.put("benzol 100mg",new Double(21));
		medinfo3.put("paracetamol 100 mg",new Double(11));
		medinfo3.put("Dolox 100 mg",new Double(12));
		medinfo3.put("Dolox 600 mg",new Double(13));
		med3.setDruglist(medinfo3);
		s3.setMedicines(med3);
		
		
		
//		System.out.println(s1);
//		System.out.println("*******************************************");
//	System.out.println(s2);
//		System.out.println("*******************************************");
//		System.out.println(s3);
		System.out.println("*******************************************************************************************************************************");	


	
List <Shop>obj=new ArrayList<>();
obj.add(s1);
obj.add(s2);
obj.add(s3);

String a[]=new String[obj.size()];


	}

}
