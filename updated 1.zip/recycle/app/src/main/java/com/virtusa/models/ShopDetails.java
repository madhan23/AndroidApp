package com.virtusa.models;

import java.util.List;

public class ShopDetails {
private String pharmacyMasterId;
private String pharmacyName;
private String isRegistered;
private String addressLine;
private String area;
private String city;
private String state;
private String postalCode;
private String country;
private String latitude;
private String longtitude;
private String openTime;
private String closedTime;
private String phone;
private String webSite;
private List<DrugInformation> drugList;
public String getPharmacyMasterId() {
	return pharmacyMasterId;
}
public void setPharmacyMasterId(String pharmacyMasterId) {
	this.pharmacyMasterId = pharmacyMasterId;
}
public String getPharmacyName() {
	return pharmacyName;
}
public void setPharmacyName(String pharmacyName) {
	this.pharmacyName = pharmacyName;
}
public String getIsRegistered() {
	return isRegistered;
}
public void setIsRegistered(String isRegistered) {
	this.isRegistered = isRegistered;
}
public String getAddressLine() {
	return addressLine;
}
public void setAddressLine(String addressLine) {
	this.addressLine = addressLine;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getPostalCode() {
	return postalCode;
}
public void setPostalCode(String postalCode) {
	this.postalCode = postalCode;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getLatitude() {
	return latitude;
}

	@Override
	public String toString() {
		return "ShopDetails{" +
				"pharmacyMasterId='" + pharmacyMasterId + '\'' +
				", pharmacyName='" + pharmacyName + '\'' +
				", isRegistered='" + isRegistered + '\'' +
				", addressLine='" + addressLine + '\'' +
				", area='" + area + '\'' +
				", city='" + city + '\'' +
				", state='" + state + '\'' +
				", postalCode='" + postalCode + '\'' +
				", country='" + country + '\'' +
				", latitude='" + latitude + '\'' +
				", longtitude='" + longtitude + '\'' +
				", openTime='" + openTime + '\'' +
				", closedTime='" + closedTime + '\'' +
				", phone='" + phone + '\'' +
				", webSite='" + webSite + '\'' +
				", drugList=" + drugList +
				'}';
	}

	public void setLatitude(String latitude) {
	this.latitude = latitude;
}
public String getLongtitude() {
	return longtitude;
}
public void setLongtitude(String longtitude) {
	this.longtitude = longtitude;
}
public String getOpenTime() {
	return openTime;
}
public void setOpenTime(String openTime) {
	this.openTime = openTime;
}
public String getClosedTime() {
	return closedTime;
}
public void setClosedTime(String closedTime) {
	this.closedTime = closedTime;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getWebSite() {
	return webSite;
}
public void setWebSite(String webSite) {
	this.webSite = webSite;
}
public List<DrugInformation> getDrugList() {
	return drugList;
}
public void setDrugList(List<DrugInformation> drugList) {
	this.drugList = drugList;
}

}
//https://stackoverflow.com/questions/1688099/converting-json-data-to-java-object

