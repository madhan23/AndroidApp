package com.example.recycle;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.virtusa.Config;
import com.virtusa.activity.HomeActivity;
import com.virtusa.recycle.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class drugselection extends AppCompatActivity {
    RequestQueue requestQueue1;
    ProgressDialog pd;
    List<String> druglist=new ArrayList<String>();
    List<String>addeddrug=new ArrayList<String>();
    private MultiAutoCompleteTextView drugName;
    TextView selectedDrugTextView;
    // Array of strings...
    ListView simpleList;
    ArrayAdapter<String> arrayAdapter;
    String countryList[] = {"India", "China", "australia", "Portugle", "America", "NewZealand"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drugselection);
        pd = new ProgressDialog(drugselection .this);
        pd.setMessage("Loading DrugList...");
        pd.show();
        dataload();
        drugName = findViewById(R.id.drug_list);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,druglist);
        drugName.setAdapter(adapter);
        drugName.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        simpleList = (ListView)findViewById(R.id.simpleListView);
        simpleList.setClickable(true);
         arrayAdapter = new ArrayAdapter<String>(this, R.layout.selecteddrugs, R.id.textView_selected,addeddrug);


    }



    private  void dataload() {

        requestQueue1 = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, Config.DrugListUrl, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                pd.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonarray=jsonObject.getJSONArray("druglist");
                    if(jsonarray!=null) {
                        for(int i=0;i<jsonarray.length();druglist.add(jsonarray.get(i++).toString()));

                    }
                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(), "Server Error", Toast.LENGTH_LONG).show();
                }
                //Log.i("VOLLEY", response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
        requestQueue1.add(stringRequest);
    }
    public  void addDrugs(View v){
        addeddrug.add(drugName.getText().toString().trim());
        drugName.setText("");
        simpleList.setAdapter(arrayAdapter);
        simpleList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item text from ListView
                String selectedItem = (String) parent.getItemAtPosition(position);

                // Display the selected item text on TextView
                Toast.makeText(drugselection.this, "2342352463456456", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
